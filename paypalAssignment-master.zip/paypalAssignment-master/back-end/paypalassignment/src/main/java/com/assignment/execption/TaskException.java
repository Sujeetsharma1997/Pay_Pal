package com.assignment.execption;

public class TaskException extends Exception {
	public TaskException() {
		// TODO Auto-generated constructor stub
	}
	public TaskException(String msg) {
		super(msg);
	}

}
